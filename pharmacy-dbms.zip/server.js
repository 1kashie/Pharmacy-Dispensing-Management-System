const express = require('express');
const oracledb = require('oracledb');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// oracledb thin mode - no Oracle client install needed on mac
oracledb.initOracleClient(); // remove this line if using thin mode only

const dbConfig = {
    user: process.env.DB_USER || 'your_username',
    password: process.env.DB_PASS || 'your_password',
    connectString: process.env.DB_CONN || 'localhost:1521/XEPDB1'
};

// helper so we don't repeat try/catch everywhere
async function runQuery(sql, params = [], options = {}) {
    let conn;
    try {
        conn = await oracledb.getConnection(dbConfig);
        const result = await conn.execute(sql, params, {
            outFormat: oracledb.OUT_FORMAT_OBJECT,
            autoCommit: true,
            ...options
        });
        return result;
    } finally {
        if (conn) await conn.close();
    }
}

// ─── PHARMACEUTICAL LABS ─────────────────────────────────────────────────────

app.get('/api/labs', async (req, res) => {
    try {
        const search = req.query.search || '';
        let sql = `SELECT * FROM pharmaceutical_lab`;
        const params = [];
        if (search) {
            sql += ` WHERE UPPER(lab_name) LIKE UPPER(:1) OR UPPER(country) LIKE UPPER(:2)`;
            params.push(`%${search}%`, `%${search}%`);
        }
        sql += ` ORDER BY lab_id`;
        const result = await runQuery(sql, params);
        res.json(result.rows);
    } catch (err) {
        console.log('GET /api/labs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/labs', async (req, res) => {
    const { lab_id, lab_name, country, fda_rating } = req.body;
    try {
        await runQuery(
            `INSERT INTO pharmaceutical_lab VALUES (:1, :2, :3, :4)`,
            [lab_id, lab_name, country, fda_rating]
        );
        res.json({ success: true });
    } catch (err) {
        console.log('POST /api/labs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/labs/:id', async (req, res) => {
    const { lab_name, country, fda_rating } = req.body;
    try {
        await runQuery(
            `UPDATE pharmaceutical_lab SET lab_name=:1, country=:2, fda_rating=:3 WHERE lab_id=:4`,
            [lab_name, country, fda_rating, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        console.log('PUT /api/labs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/labs/:id', async (req, res) => {
    try {
        await runQuery(`DELETE FROM pharmaceutical_lab WHERE lab_id=:1`, [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        console.log('DELETE /api/labs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

// ─── DRUGS ────────────────────────────────────────────────────────────────────

app.get('/api/drugs', async (req, res) => {
    try {
        const search = req.query.search || '';
        let sql = `SELECT d.*, l.lab_name FROM prescription_drug d
                   LEFT JOIN pharmaceutical_lab l ON d.lab_id = l.lab_id`;
        const params = [];
        if (search) {
            sql += ` WHERE UPPER(d.drug_name) LIKE UPPER(:1) OR UPPER(d.drug_code) LIKE UPPER(:2)`;
            params.push(`%${search}%`, `%${search}%`);
        }
        sql += ` ORDER BY d.drug_code`;
        const result = await runQuery(sql, params);
        res.json(result.rows);
    } catch (err) {
        console.log('GET /api/drugs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/drugs', async (req, res) => {
    const { drug_code, drug_name, base_price, controlled_substance, expiry_date, lab_id } = req.body;
    try {
        await runQuery(
            `INSERT INTO prescription_drug VALUES (:1, :2, :3, :4, TO_DATE(:5,'YYYY-MM-DD'), :6)`,
            [drug_code, drug_name, base_price, controlled_substance, expiry_date, lab_id]
        );
        res.json({ success: true });
    } catch (err) {
        console.log('POST /api/drugs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/drugs/:code', async (req, res) => {
    const { drug_name, base_price, controlled_substance, expiry_date, lab_id } = req.body;
    try {
        await runQuery(
            `UPDATE prescription_drug SET drug_name=:1, base_price=:2, controlled_substance=:3,
             expiry_date=TO_DATE(:4,'YYYY-MM-DD'), lab_id=:5 WHERE drug_code=:6`,
            [drug_name, base_price, controlled_substance, expiry_date, lab_id, req.params.code]
        );
        res.json({ success: true });
    } catch (err) {
        console.log('PUT /api/drugs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/drugs/:code', async (req, res) => {
    try {
        await runQuery(`DELETE FROM prescription_drug WHERE drug_code=:1`, [req.params.code]);
        res.json({ success: true });
    } catch (err) {
        console.log('DELETE /api/drugs error:', err.message);
        res.status(500).json({ error: err.message });
    }
});

// ─── PATIENTS ─────────────────────────────────────────────────────────────────

app.get('/api/patients', async (req, res) => {
    try {
        const result = await runQuery(
            `SELECT patient_id, patient_name,
             TO_CHAR(dob, 'YYYY-MM-DD') AS dob,
             contact_no, allergy_notes FROM patient ORDER BY patient_id`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/patients', async (req, res) => {
    const { patient_id, patient_name, dob, contact_no, allergy_notes } = req.body;
    try {
        await runQuery(
            `INSERT INTO patient VALUES (:1, :2, TO_DATE(:3,'YYYY-MM-DD'), :4, :5)`,
            [patient_id, patient_name, dob, contact_no, allergy_notes]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/patients/:id', async (req, res) => {
    const { patient_name, dob, contact_no, allergy_notes } = req.body;
    try {
        await runQuery(
            `UPDATE patient SET patient_name=:1, dob=TO_DATE(:2,'YYYY-MM-DD'),
             contact_no=:3, allergy_notes=:4 WHERE patient_id=:5`,
            [patient_name, dob, contact_no, allergy_notes, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/patients/:id', async (req, res) => {
    try {
        await runQuery(`DELETE FROM patient WHERE patient_id=:1`, [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ─── PHYSICIANS ───────────────────────────────────────────────────────────────

app.get('/api/physicians', async (req, res) => {
    try {
        const result = await runQuery(`SELECT * FROM physician ORDER BY physician_id`);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/physicians', async (req, res) => {
    const { physician_id, physician_name, specialization, license_no, contact_no } = req.body;
    try {
        await runQuery(
            `INSERT INTO physician VALUES (:1, :2, :3, :4, :5)`,
            [physician_id, physician_name, specialization, license_no, contact_no]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/physicians/:id', async (req, res) => {
    const { physician_name, specialization, license_no, contact_no } = req.body;
    try {
        await runQuery(
            `UPDATE physician SET physician_name=:1, specialization=:2,
             license_no=:3, contact_no=:4 WHERE physician_id=:5`,
            [physician_name, specialization, license_no, contact_no, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/physicians/:id', async (req, res) => {
    try {
        await runQuery(`DELETE FROM physician WHERE physician_id=:1`, [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ─── PRESCRIPTIONS ────────────────────────────────────────────────────────────

app.get('/api/prescriptions', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT p.prescription_id, p.quantity_prescribed,
                   TO_CHAR(p.date_issued, 'YYYY-MM-DD') AS date_issued,
                   p.dosage_instructions,
                   p.patient_id, pt.patient_name,
                   p.physician_id, ph.physician_name,
                   p.drug_code, d.drug_name
            FROM prescription p
            JOIN patient pt ON p.patient_id = pt.patient_id
            JOIN physician ph ON p.physician_id = ph.physician_id
            JOIN prescription_drug d ON p.drug_code = d.drug_code
            ORDER BY p.prescription_id`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/prescriptions', async (req, res) => {
    const { prescription_id, quantity_prescribed, date_issued, dosage_instructions, patient_id, physician_id, drug_code } = req.body;
    try {
        await runQuery(
            `INSERT INTO prescription VALUES (:1, :2, TO_DATE(:3,'YYYY-MM-DD'), :4, :5, :6, :7)`,
            [prescription_id, quantity_prescribed, date_issued, dosage_instructions, patient_id, physician_id, drug_code]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/prescriptions/:id', async (req, res) => {
    const { quantity_prescribed, date_issued, dosage_instructions, patient_id, physician_id, drug_code } = req.body;
    try {
        await runQuery(
            `UPDATE prescription SET quantity_prescribed=:1, date_issued=TO_DATE(:2,'YYYY-MM-DD'),
             dosage_instructions=:3, patient_id=:4, physician_id=:5, drug_code=:6
             WHERE prescription_id=:7`,
            [quantity_prescribed, date_issued, dosage_instructions, patient_id, physician_id, drug_code, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/prescriptions/:id', async (req, res) => {
    try {
        await runQuery(`DELETE FROM prescription WHERE prescription_id=:1`, [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ─── PHARMACY STAFF ───────────────────────────────────────────────────────────

app.get('/api/staff', async (req, res) => {
    try {
        const result = await runQuery(`SELECT * FROM pharmacy_staff ORDER BY staff_id`);
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/staff', async (req, res) => {
    const { staff_id, staff_name, designation, shift, monthly_salary } = req.body;
    try {
        await runQuery(
            `INSERT INTO pharmacy_staff VALUES (:1, :2, :3, :4, :5)`,
            [staff_id, staff_name, designation, shift, monthly_salary]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/staff/:id', async (req, res) => {
    const { staff_name, designation, shift, monthly_salary } = req.body;
    try {
        await runQuery(
            `UPDATE pharmacy_staff SET staff_name=:1, designation=:2,
             shift=:3, monthly_salary=:4 WHERE staff_id=:5`,
            [staff_name, designation, shift, monthly_salary, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/staff/:id', async (req, res) => {
    try {
        await runQuery(`DELETE FROM pharmacy_staff WHERE staff_id=:1`, [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ─── DISPENSING RECORDS ───────────────────────────────────────────────────────

app.get('/api/dispensing', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT dr.dispensing_id,
                   TO_CHAR(dr.dispense_date,'YYYY-MM-DD') AS dispense_date,
                   dr.quantity_dispensed, dr.amount_charged, dr.status,
                   dr.prescription_id, dr.staff_id, s.staff_name
            FROM dispensing_record dr
            JOIN pharmacy_staff s ON dr.staff_id = s.staff_id
            ORDER BY dr.dispensing_id`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.post('/api/dispensing', async (req, res) => {
    const { dispensing_id, dispense_date, quantity_dispensed, amount_charged, status, prescription_id, staff_id } = req.body;
    try {
        await runQuery(
            `INSERT INTO dispensing_record VALUES (:1, TO_DATE(:2,'YYYY-MM-DD'), :3, :4, :5, :6, :7)`,
            [dispensing_id, dispense_date, quantity_dispensed, amount_charged, status, prescription_id, staff_id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.put('/api/dispensing/:id', async (req, res) => {
    const { dispense_date, quantity_dispensed, amount_charged, status, prescription_id, staff_id } = req.body;
    try {
        await runQuery(
            `UPDATE dispensing_record SET dispense_date=TO_DATE(:1,'YYYY-MM-DD'),
             quantity_dispensed=:2, amount_charged=:3, status=:4,
             prescription_id=:5, staff_id=:6 WHERE dispensing_id=:7`,
            [dispense_date, quantity_dispensed, amount_charged, status, prescription_id, staff_id, req.params.id]
        );
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.delete('/api/dispensing/:id', async (req, res) => {
    try {
        await runQuery(`DELETE FROM dispensing_record WHERE dispensing_id=:1`, [req.params.id]);
        res.json({ success: true });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ─── ANALYTICS / REPORTS ──────────────────────────────────────────────────────

// single-row functions: UPPER, LENGTH, ROUND, SUBSTR on patients & drugs
app.get('/api/reports/string-functions', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT
                UPPER(patient_name) AS patient_upper,
                LENGTH(patient_name) AS name_length,
                SUBSTR(patient_name, 1, 5) AS name_prefix,
                allergy_notes
            FROM patient`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/reports/drug-functions', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT
                UPPER(drug_name) AS drug_upper,
                LENGTH(drug_name) AS name_length,
                ROUND(base_price, 0) AS price_rounded,
                SUBSTR(drug_code, 1, 3) AS code_prefix
            FROM prescription_drug`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// GROUP BY: revenue & order count per staff
app.get('/api/reports/staff-revenue', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT
                dr.staff_id,
                s.staff_name,
                COUNT(dr.dispensing_id) AS total_orders,
                SUM(dr.amount_charged) AS total_revenue,
                ROUND(AVG(dr.amount_charged), 2) AS avg_per_order
            FROM dispensing_record dr
            JOIN pharmacy_staff s ON dr.staff_id = s.staff_id
            GROUP BY dr.staff_id, s.staff_name
            ORDER BY total_revenue DESC`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// HAVING: labs where avg drug price > $30
app.get('/api/reports/expensive-labs', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT
                d.lab_id,
                l.lab_name,
                l.fda_rating,
                COUNT(d.drug_code) AS drug_count,
                ROUND(AVG(d.base_price), 2) AS avg_price
            FROM prescription_drug d
            JOIN pharmaceutical_lab l ON d.lab_id = l.lab_id
            GROUP BY d.lab_id, l.lab_name, l.fda_rating
            HAVING AVG(d.base_price) > 30
            ORDER BY avg_price DESC`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// subquery: drugs priced above the overall average
app.get('/api/reports/above-avg-drugs', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT drug_code, drug_name, base_price,
                   ROUND((SELECT AVG(base_price) FROM prescription_drug), 2) AS db_avg,
                   ROUND(base_price - (SELECT AVG(base_price) FROM prescription_drug), 2) AS above_by
            FROM prescription_drug
            WHERE base_price > (SELECT AVG(base_price) FROM prescription_drug)
            ORDER BY base_price DESC`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// multi-table JOIN: complete dispensing summary
app.get('/api/reports/full-join', async (req, res) => {
    try {
        const result = await runQuery(`
            SELECT
                dr.dispensing_id,
                TO_CHAR(dr.dispense_date,'DD-Mon-YYYY') AS dispense_date,
                pt.patient_name,
                ph.physician_name,
                d.drug_name,
                d.base_price,
                pr.quantity_prescribed,
                dr.quantity_dispensed,
                dr.amount_charged,
                dr.status,
                s.staff_name AS dispensed_by
            FROM dispensing_record dr
            JOIN prescription pr ON dr.prescription_id = pr.prescription_id
            JOIN patient pt ON pr.patient_id = pt.patient_id
            JOIN physician ph ON pr.physician_id = ph.physician_id
            JOIN prescription_drug d ON pr.drug_code = d.drug_code
            JOIN pharmacy_staff s ON dr.staff_id = s.staff_id
            ORDER BY dr.dispensing_id`
        );
        res.json(result.rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// dashboard stats
app.get('/api/stats', async (req, res) => {
    try {
        const [labs, drugs, patients, dispense] = await Promise.all([
            runQuery(`SELECT COUNT(*) AS cnt FROM pharmaceutical_lab`),
            runQuery(`SELECT COUNT(*) AS cnt FROM prescription_drug`),
            runQuery(`SELECT COUNT(*) AS cnt FROM patient`),
            runQuery(`SELECT SUM(amount_charged) AS total FROM dispensing_record WHERE status='Completed'`)
        ]);
        res.json({
            labs: labs.rows[0].CNT,
            drugs: drugs.rows[0].CNT,
            patients: patients.rows[0].CNT,
            revenue: dispense.rows[0].TOTAL || 0
        });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(3000, () => console.log('Pharmacy DBMS running at http://localhost:3000'));
