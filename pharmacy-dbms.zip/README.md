# Pharmacy Dispensing Management System
### DBMS Project — VIT | 25BCE2663

---

## macOS Prerequisites & Setup

### 1. Install Node.js (if not installed)
```bash
# using Homebrew (recommended)
brew install node

# verify
node -v    # should show v18+
npm -v
```

### 2. Install Oracle Database XE (macOS via Docker — easiest way)
Oracle doesn't have a native macOS installer, so use Docker:

```bash
# install Docker Desktop from https://www.docker.com/products/docker-desktop/
# then pull and run Oracle XE
docker pull container-registry.oracle.com/database/express:21.3.0-xe

docker run -d \
  --name oracle-xe \
  -p 1521:1521 \
  -e ORACLE_PWD=YourPassword123 \
  container-registry.oracle.com/database/express:21.3.0-xe

# wait ~2 minutes for startup, then check
docker logs oracle-xe | tail -20
# look for: DATABASE IS READY TO USE!
```

### 3. Connect with SQL*Plus and run the schema
```bash
# connect as sysdba first and create a user
docker exec -it oracle-xe sqlplus sys/YourPassword123@//localhost:1521/XEPDB1 as sysdba

-- inside SQL*Plus:
CREATE USER pharmauser IDENTIFIED BY pharmapass123;
GRANT CONNECT, RESOURCE, CREATE SESSION TO pharmauser;
GRANT UNLIMITED TABLESPACE TO pharmauser;
EXIT;

# now connect as your new user
docker exec -it oracle-xe sqlplus pharmauser/pharmapass123@//localhost:1521/XEPDB1

-- paste the full schema + seed data from schema.sql here, then:
COMMIT;
EXIT;
```

### 4. Clone and install the Node.js project
```bash
cd ~/Desktop
# put the pharmacy-dbms folder here, then:
cd pharmacy-dbms
npm install
```

### 5. Set your DB credentials (edit server.js OR use env vars)
```bash
# either edit the dbConfig in server.js directly:
#   user: 'pharmauser'
#   password: 'pharmapass123'
#   connectString: 'localhost:1521/XEPDB1'

# or run with env vars:
DB_USER=pharmauser DB_PASS=pharmapass123 DB_CONN=localhost:1521/XEPDB1 node server.js
```

### 6. Start the server
```bash
npm start
# or for auto-reload during dev:
npm run dev

# open in browser:
open http://localhost:3000
```

---

## Thin Mode (no Oracle Client install needed)

`oracledb` v6+ supports **Thin Mode** on macOS without needing the Oracle Instant Client installed. 

In `server.js`, the line `oracledb.initOracleClient()` enables Thick mode. If you don't have Oracle Instant Client, **remove that line** — Thin Mode activates automatically and works fine for this project.

---

## Project Structure
```
pharmacy-dbms/
├── server.js          ← Express backend, all API routes
├── package.json
├── README.md
└── public/
    └── index.html     ← Full frontend (Tailwind CSS)
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET/POST | `/api/labs` | List or add labs |
| PUT/DELETE | `/api/labs/:id` | Update or delete lab |
| GET/POST | `/api/drugs` | List (with search) or add drugs |
| PUT/DELETE | `/api/drugs/:code` | Update or delete drug |
| GET/POST | `/api/patients` | List or add patients |
| PUT/DELETE | `/api/patients/:id` | Update or delete patient |
| GET/POST | `/api/physicians` | List or add physicians |
| PUT/DELETE | `/api/physicians/:id` | Update or delete physician |
| GET/POST | `/api/staff` | List or add staff |
| PUT/DELETE | `/api/staff/:id` | Update or delete staff |
| GET/POST | `/api/prescriptions` | List (JOIN view) or add prescriptions |
| PUT/DELETE | `/api/prescriptions/:id` | Update or delete prescription |
| GET/POST | `/api/dispensing` | List or add dispensing records |
| PUT/DELETE | `/api/dispensing/:id` | Update or delete record |
| GET | `/api/stats` | Dashboard counts and revenue |
| GET | `/api/reports/string-functions` | UPPER, LENGTH, SUBSTR on patients |
| GET | `/api/reports/drug-functions` | UPPER, LENGTH, ROUND, SUBSTR on drugs |
| GET | `/api/reports/staff-revenue` | GROUP BY revenue per staff |
| GET | `/api/reports/expensive-labs` | HAVING avg price > $30 |
| GET | `/api/reports/above-avg-drugs` | Subquery: price above average |
| GET | `/api/reports/full-join` | 6-table JOIN dispensing summary |
